// sdl_system.c
#include "sdl_system.h"
#include <stdio.h>

static SDL_SystemConfig current_config = {0};

SDL_Result SDL_System_Init(const SDL_SystemConfig* config) {
    if (!config) return SDL_ERROR_INIT;
    
    current_config = *config;
    
    // 初始化SDL
    if (SDL_Init(config->sdl_flags) != 0) {
        return SDL_ERROR_INIT;
    }
    
    // 初始化SDL_image
    if ((IMG_Init(config->image_flags) & config->image_flags) != config->image_flags) {
        SDL_Quit();
        return SDL_ERROR_IMAGE;
    }
    
    // 初始化SDL_ttf
    if (TTF_Init() != 0) {
        IMG_Quit();
        SDL_Quit();
        return SDL_ERROR_TTF;
    }
    current_config.ttf_initialized = 1;
    
    // 初始化SDL_mixer
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) != 0) {
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return SDL_ERROR_MIXER;
    }
    current_config.mixer_initialized = 1;
    
    return SDL_SUCCESS;
}

void SDL_System_Quit(void) {
    if (current_config.mixer_initialized) {
        Mix_CloseAudio();
        Mix_Quit();
    }
    if (current_config.ttf_initialized) {
        TTF_Quit();
    }
    IMG_Quit();
    SDL_Quit();
}

const char* SDL_GetLastErrorString(void) {
    return SDL_GetError();
}