// texture.c
#include "texture.h"
#include "font.h"
#include <stdlib.h>

SDL_Result Texture_CreateFromFile(Texture** texture, Renderer* renderer, 
                                 const char* filepath) {
    if (!texture || !renderer) return SDL_ERROR_INIT;
    
    *texture = (Texture*)malloc(sizeof(Texture));
    if (!*texture) return SDL_ERROR_INIT;
    
    (*texture)->renderer = renderer;
    
    // 使用SDL_image加载纹理
    SDL_Surface* surface = IMG_Load(filepath);
    if (!surface) {
        free(*texture);
        *texture = NULL;
        return SDL_ERROR_FILE;
    }
    
    (*texture)->sdl_texture = SDL_CreateTextureFromSurface(
        renderer->sdl_renderer, surface
    );
    
    (*texture)->width = surface->w;
    (*texture)->height = surface->h;
    
    SDL_FreeSurface(surface);
    
    if (!(*texture)->sdl_texture) {
        free(*texture);
        *texture = NULL;
        return SDL_ERROR_FILE;
    }
    
    return SDL_SUCCESS;
}

void Texture_Destroy(Texture* texture) {
    if (texture) {
        if (texture->sdl_texture) {
            SDL_DestroyTexture(texture->sdl_texture);
        }
        free(texture);
    }
}

void Texture_Render(Texture* texture, int x, int y) {
    if (!texture || !texture->sdl_texture) return;
    
    SDL_Rect dest = {x, y, texture->width, texture->height};
    SDL_RenderCopy(texture->renderer->sdl_renderer, 
                  texture->sdl_texture, NULL, &dest);
}

void Texture_RenderEx(Texture* texture, int x, int y, 
                     double angle, SDL_RendererFlip flip) {
    if (!texture || !texture->sdl_texture) return;
    
    SDL_Rect dest = {x, y, texture->width, texture->height};
    SDL_RenderCopyEx(texture->renderer->sdl_renderer,
                    texture->sdl_texture, NULL, &dest,
                    angle, NULL, flip);
}