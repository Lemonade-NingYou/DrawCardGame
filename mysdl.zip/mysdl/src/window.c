// window.c
#include "window.h"
#include <stdlib.h>

SDL_Result Window_Create(Window** window, const char* title, 
                        int width, int height, Uint32 flags) {
    if (!window) return SDL_ERROR_INIT;
    
    *window = (Window*)malloc(sizeof(Window));
    if (!*window) return SDL_ERROR_INIT;
    
    (*window)->title = title;
    (*window)->width = width;
    (*window)->height = height;
    (*window)->flags = flags;
    
    (*window)->sdl_window = SDL_CreateWindow(
        title, 
        SDL_WINDOWPOS_CENTERED, 
        SDL_WINDOWPOS_CENTERED,
        width, height, flags
    );
    
    if (!(*window)->sdl_window) {
        free(*window);
        *window = NULL;
        return SDL_ERROR_WINDOW;
    }
    
    return SDL_SUCCESS;
}

void Window_Destroy(Window* window) {
    if (window) {
        if (window->sdl_window) {
            SDL_DestroyWindow(window->sdl_window);
        }
        free(window);
    }
}

SDL_Result Renderer_Create(Renderer** renderer, Window* window, Uint32 flags) {
    if (!renderer || !window) return SDL_ERROR_INIT;
    
    *renderer = (Renderer*)malloc(sizeof(Renderer));
    if (!*renderer) return SDL_ERROR_INIT;
    
    (*renderer)->window = window;
    (*renderer)->sdl_renderer = SDL_CreateRenderer(
        window->sdl_window, -1, flags
    );
    
    if (!(*renderer)->sdl_renderer) {
        free(*renderer);
        *renderer = NULL;
        return SDL_ERROR_RENDERER;
    }
    
    // 设置默认清除颜色
    (*renderer)->clear_color = (SDL_Color){0, 0, 0, 255};
    
    return SDL_SUCCESS;
}

void Renderer_Destroy(Renderer* renderer) {
    if (renderer) {
        if (renderer->sdl_renderer) {
            SDL_DestroyRenderer(renderer->sdl_renderer);
        }
        free(renderer);
    }
}

void Renderer_Clear(Renderer* renderer) {
    if (renderer && renderer->sdl_renderer) {
        SDL_SetRenderDrawColor(renderer->sdl_renderer,
                              renderer->clear_color.r,
                              renderer->clear_color.g,
                              renderer->clear_color.b,
                              renderer->clear_color.a);
        SDL_RenderClear(renderer->sdl_renderer);
    }
}

void Renderer_Present(Renderer* renderer) {
    if (renderer && renderer->sdl_renderer) {
        SDL_RenderPresent(renderer->sdl_renderer);
    }
}

void Renderer_SetDrawColor(Renderer* renderer, Uint8 r, Uint8 g, Uint8 b, Uint8 a) {
    if (renderer && renderer->sdl_renderer) {
        SDL_SetRenderDrawColor(renderer->sdl_renderer, r, g, b, a);
        renderer->clear_color = (SDL_Color){r, g, b, a};
    }
}