// sdl_system.h
#ifndef SDL_SYSTEM_H
#define SDL_SYSTEM_H

#include "my_sdl.h"

typedef struct {
    Uint32 sdl_flags;
    int image_flags;
    int ttf_initialized;
    int mixer_initialized;
} SDL_SystemConfig;

// 系统管理
SDL_Result SDL_System_Init(const SDL_SystemConfig* config);
void SDL_System_Quit(void);
const char* SDL_GetLastErrorString(void);

#endif