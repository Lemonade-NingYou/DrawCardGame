// window.h
#ifndef WINDOW_H
#define WINDOW_H

#include "my_sdl.h"

struct Window {
    SDL_Window* sdl_window;
    const char* title;
    int width;
    int height;
    Uint32 flags;
};

struct Renderer {
    SDL_Renderer* sdl_renderer;
    Window* window;
    SDL_Color clear_color;
};

// 窗口创建和销毁
SDL_Result Window_Create(Window** window, const char* title, 
                        int width, int height, Uint32 flags);
void Window_Destroy(Window* window);

// 渲染器创建和销毁
SDL_Result Renderer_Create(Renderer** renderer, Window* window, 
                          Uint32 flags);
void Renderer_Destroy(Renderer* renderer);

// 渲染操作
void Renderer_Clear(Renderer* renderer);
void Renderer_Present(Renderer* renderer);
void Renderer_SetDrawColor(Renderer* renderer, 
                          Uint8 r, Uint8 g, Uint8 b, Uint8 a);

#endif