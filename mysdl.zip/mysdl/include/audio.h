// audio.h
#ifndef AUDIO_H
#define AUDIO_H

#include "my_sdl.h"

struct Music {
    Mix_Music* mix_music;
    const char* filepath;
};

struct Sound {
    Mix_Chunk* mix_chunk;
    const char* filepath;
};

// 音频系统初始化
SDL_Result Audio_Init(int frequency, Uint16 format, int channels, int chunksize);
void Audio_Quit(void);

// 音乐操作
SDL_Result Music_Create(Music** music, const char* filepath);
void Music_Destroy(Music* music);
void Music_Play(Music* music, int loops);
void Music_Pause(void);
void Music_Resume(void);
void Music_Stop(void);

// 音效操作
SDL_Result Sound_Create(Sound** sound, const char* filepath);
void Sound_Destroy(Sound* sound);
void Sound_Play(Sound* sound, int loops);

#endif