// font.h
#ifndef FONT_H
#define FONT_H

#include "my_sdl.h"

struct Font {
    TTF_Font* ttf_font;
    const char* filepath;
    int size;
};

SDL_Result Font_Create(Font** font, const char* filepath, int size);
void Font_Destroy(Font* font);

#endif