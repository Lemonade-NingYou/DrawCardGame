// texture.h
#ifndef TEXTURE_H
#define TEXTURE_H

#include "my_sdl.h"

struct Texture {
    SDL_Texture* sdl_texture;
    int width;
    int height;
    Renderer* renderer;
};

// 纹理操作
SDL_Result Texture_CreateFromFile(Texture** texture, Renderer* renderer, 
                                 const char* filepath);
SDL_Result Texture_CreateFromText(Texture** texture, Renderer* renderer,
                                 Font* font, const char* text, 
                                 SDL_Color color);
void Texture_Destroy(Texture* texture);
void Texture_Render(Texture* texture, int x, int y);
void Texture_RenderEx(Texture* texture, int x, int y, 
                     double angle, SDL_RendererFlip flip);

#endif