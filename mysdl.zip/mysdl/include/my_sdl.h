// my_sdl.h
#ifndef MY_SDL_H
#define MY_SDL_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>

typedef enum {
    SDL_SUCCESS = 0,
    SDL_ERROR_INIT,
    SDL_ERROR_WINDOW,
    SDL_ERROR_RENDERER,
    SDL_ERROR_IMAGE,
    SDL_ERROR_TTF,
    SDL_ERROR_MIXER,
    SDL_ERROR_FILE
} SDL_Result;

// 前向声明
typedef struct Window Window;
typedef struct Renderer Renderer;
typedef struct Texture Texture;
typedef struct Font Font;
typedef struct Music Music;
typedef struct Sound Sound;

#endif